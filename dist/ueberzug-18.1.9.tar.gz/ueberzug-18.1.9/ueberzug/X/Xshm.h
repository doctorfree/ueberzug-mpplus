#ifndef __XSHM_H__
#define __XSHM_H__
#include "python.h"


extern PyTypeObject ImageType;
#endif
