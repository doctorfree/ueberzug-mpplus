__version__ = '18.1.9'
__license__ = 'GPLv3'
__description__ ='ueberzug is a command line util which allows to display images in combination with X11'
__url_repository__ = 'https://github.com/doctorfree/ueberzug-mpplus'
__url_bug_reports__ = 'https://github.com/doctorfree/ueberzug-mpplus/issues'
__url_project__ = __url_repository__
__author__ = 'Nico Bäurer'
