import ueberzug


def main(_):
    print(ueberzug.__version__)
